const { app, BrowserWindow } = require("electron");
const path = require("path");


function createWindow() {

    const mainWindow = new BrowserWindow({

        width: 1400,
        height: 850,

        minWidth: 1000,
        minHeight: 650,

        title: "Notebook",

        backgroundColor: "#292929",

        webPreferences: {

            contextIsolation: true,

            nodeIntegration: false

        }

    });


    mainWindow.loadFile(
        path.join(__dirname, "index.html")
    );
}


app.whenReady().then(() => {

    createWindow();


    app.on("activate", () => {

        if (
            BrowserWindow.getAllWindows().length === 0
        ) {

            createWindow();

        }

    });

});


app.on("window-all-closed", () => {

    if (process.platform !== "darwin") {

        app.quit();

    }

});