/* =========================================
   NOTES
========================================= */

let notes =
    JSON.parse(localStorage.getItem("notes")) || [];

let currentNoteId = null;


/* =========================================
   AUDIO VARIABLES
========================================= */

let db = null;

let mediaRecorder = null;

let audioChunks = [];

let currentRecordingNote = null;


/* =========================================
   DOM ELEMENTS
========================================= */

const notesList =
    document.getElementById("notesList");

const noteTitle =
    document.getElementById("noteTitle");

const noteText =
    document.getElementById("noteText");

const noteStats =
    document.getElementById("noteStats");

const lastEdited =
    document.getElementById("lastEdited");

const recordBtn =
    document.getElementById("recordBtn");

const recordingStatus =
    document.getElementById("recordingStatus");

const savedRecording =
    document.getElementById("savedRecording");

const newNoteBtn =
    document.getElementById("newNoteBtn");

const deleteNoteBtn =
    document.getElementById("deleteNoteBtn");


/* =========================================
   INITIALIZE DATABASE
========================================= */

const request = indexedDB.open(
    "NotebookDatabase",
    1
);


request.onupgradeneeded = function(event) {

    db = event.target.result;

    if (!db.objectStoreNames.contains("recordings")) {

        db.createObjectStore(
            "recordings",
            {
                keyPath: "noteId"
            }
        );
    }
};


request.onsuccess = function(event) {

    db = event.target.result;

    initializeApp();
};


request.onerror = function(event) {

    console.error(
        "Database error:",
        event.target.error
    );
};


/* =========================================
   INITIALIZE APP
========================================= */

function initializeApp() {

    if (notes.length === 0) {

        createFirstNote();

    } else {

        currentNoteId = notes[0].id;

        renderNotes();

        loadCurrentNote();
    }
}


/* =========================================
   CREATE FIRST NOTE
========================================= */

function createFirstNote() {

    const newNote = {

        id: Date.now().toString(),

        title: "Untitled",

        text: "",

        updatedAt: new Date().toISOString()

    };

    notes.push(newNote);

    saveNotes();

    currentNoteId = newNote.id;

    renderNotes();

    loadCurrentNote();
}


/* =========================================
   NEW NOTE
========================================= */

newNoteBtn.addEventListener(
    "click",
    function() {

        const newNote = {

            id: Date.now().toString(),

            title: "Untitled",

            text: "",

            updatedAt: new Date().toISOString()

        };

        notes.unshift(newNote);

        saveNotes();

        currentNoteId = newNote.id;

        renderNotes();

        loadCurrentNote();

        noteTitle.focus();
    }
);


/* =========================================
   RENDER NOTES SIDEBAR
========================================= */

function renderNotes() {

    notesList.innerHTML = "";

    if (notes.length === 0) {

        notesList.innerHTML = `
            <div class="empty-notes">
                No notes yet
            </div>
        `;

        return;
    }


    notes.forEach(function(note) {

        const item =
            document.createElement("div");

        item.className = "note-item";


        if (note.id === currentNoteId) {

            item.classList.add("active");
        }


        item.innerHTML = `

            <span class="note-icon">
                📄
            </span>

            <span>
                ${escapeHTML(
                    note.title || "Untitled"
                )}
            </span>

        `;


        item.addEventListener(
            "click",
            function() {

                selectNote(note.id);

            }
        );


        notesList.appendChild(item);
    });
}


/* =========================================
   SELECT NOTE
========================================= */

function selectNote(id) {

    saveCurrentNote();

    currentNoteId = id;

    renderNotes();

    loadCurrentNote();
}


/* =========================================
   LOAD CURRENT NOTE
========================================= */

async function loadCurrentNote() {

    const note =
        notes.find(
            function(n) {
                return n.id === currentNoteId;
            }
        );


    if (!note) {
        return;
    }


    noteTitle.value =
        note.title || "";


    noteText.value =
        note.text || "";


    updateStats();


    if (note.updatedAt) {

        lastEdited.textContent =
            "Last edited: " +
            formatDate(note.updatedAt);

    } else {

        lastEdited.textContent =
            "Last edited: —";
    }


    resetRecordingInterface();


    const audio =
        await getAudio(note.id);


    if (audio) {

        showSavedAudio(
            note.id,
            audio
        );
    }
}


/* =========================================
   SAVE CURRENT NOTE
========================================= */

function saveCurrentNote() {

    if (!currentNoteId) {
        return;
    }


    const note =
        notes.find(
            function(n) {
                return n.id === currentNoteId;
            }
        );


    if (!note) {
        return;
    }


    note.title =
        noteTitle.value.trim() ||
        "Untitled";


    note.text =
        noteText.value;


    note.updatedAt =
        new Date().toISOString();


    saveNotes();
}


/* =========================================
   AUTO SAVE TITLE
========================================= */

noteTitle.addEventListener(
    "input",
    function() {

        saveCurrentNote();

        renderNotes();

        updateStats();

        updateEditedTime();
    }
);


/* =========================================
   AUTO SAVE TEXT
========================================= */

noteText.addEventListener(
    "input",
    function() {

        saveCurrentNote();

        updateStats();

        updateEditedTime();
    }
);


/* =========================================
   UPDATE EDITED TIME
========================================= */

function updateEditedTime() {

    lastEdited.textContent =
        "Last edited: " +
        formatDate(
            new Date().toISOString()
        );
}


/* =========================================
   WORD + CHARACTER COUNTER
========================================= */

function updateStats() {

    const text =
        noteText.value.trim();


    const characters =
        noteText.value.length;


    let words = 0;


    if (text.length > 0) {

        words =
            text.split(/\s+/).length;
    }


    noteStats.innerHTML =

        `Words: ${words}` +

        ` &nbsp; | &nbsp; ` +

        `Characters: ${characters}`;
}


/* =========================================
   RECORD BUTTON
========================================= */

recordBtn.addEventListener(
    "click",
    async function() {

        if (
            mediaRecorder &&
            mediaRecorder.state === "recording"
        ) {

            stopRecording();

        } else {

            await startRecording();

        }
    }
);


/* =========================================
   START RECORDING
========================================= */

async function startRecording() {

    if (!currentNoteId) {

        alert(
            "Please select a note first."
        );

        return;
    }


    try {

        const stream =
            await navigator.mediaDevices
                .getUserMedia({
                    audio: true
                });


        mediaRecorder =
            new MediaRecorder(stream);


        audioChunks = [];

        currentRecordingNote =
            currentNoteId;


        mediaRecorder.ondataavailable =
            function(event) {

                if (
                    event.data.size > 0
                ) {

                    audioChunks.push(
                        event.data
                    );
                }
            };


        mediaRecorder.onstop =
            async function() {

                const audioBlob =
                    new Blob(
                        audioChunks,
                        {
                            type: "audio/webm"
                        }
                    );


                await saveAudio(
                    currentRecordingNote,
                    audioBlob
                );


                stream
                    .getTracks()
                    .forEach(
                        function(track) {

                            track.stop();

                        }
                    );


                showSavedAudio(
                    currentRecordingNote,
                    audioBlob
                );


                recordingStatus.classList.remove(
                    "active"
                );


                recordingStatus.innerHTML = `

                    <div class="microphone">
                        ✓
                    </div>

                    <p>
                        Recording saved
                    </p>

                    <small>
                        Your recording is ready to play
                    </small>

                `;


                recordBtn.textContent =
                    "🔴  Start Recording";


                recordBtn.classList.remove(
                    "recording"
                );
            };


        mediaRecorder.start();


        recordBtn.textContent =
            "⏹️  Stop Recording";


        recordBtn.classList.add(
            "recording"
        );


        recordingStatus.classList.add(
            "active"
        );


        recordingStatus.innerHTML = `

            <div class="microphone">
                🎙️
            </div>

            <p>
                Recording...
            </p>

            <small>
                Click "Stop Recording" when finished
            </small>

        `;

    }

    catch (error) {

        console.error(error);

        alert(
            "Microphone access was denied. " +
            "Please allow microphone access " +
            "in your browser."
        );
    }
}


/* =========================================
   STOP RECORDING
========================================= */

function stopRecording() {

    if (
        mediaRecorder &&
        mediaRecorder.state === "recording"
    ) {

        mediaRecorder.stop();
    }
}


/* =========================================
   SHOW SAVED AUDIO
========================================= */

function showSavedAudio(
    noteId,
    audioBlob
) {

    const audioURL =
        URL.createObjectURL(
            audioBlob
        );


    savedRecording.innerHTML = `

        <div class="audio-card">

            <div class="audio-info">

                <div class="audio-icon">
                    🎵
                </div>

                <div>

                    <div class="audio-name">
                        ${getAudioFileName(noteId)}
                    </div>

                    <div class="audio-time">
                        Saved recording
                    </div>

                </div>

            </div>


            <audio
                class="audio-player"
                controls
                src="${audioURL}">
            </audio>


            <button
                class="delete-recording-btn"
                onclick="deleteCurrentAudio()">

                🗑️ &nbsp; Delete Recording

            </button>

        </div>

    `;
}


/* =========================================
   AUDIO FILE NAME
========================================= */

function getAudioFileName(noteId) {

    const note =
        notes.find(
            function(n) {
                return n.id === noteId;
            }
        );


    if (!note) {

        return "voice_recording.webm";
    }


    let title =
        note.title || "voice_recording";


    title =
        title
            .toLowerCase()
            .replace(
                /[^a-z0-9]+/g,
                "_"
            );


    return title + ".webm";
}


/* =========================================
   DELETE CURRENT AUDIO
========================================= */

async function deleteCurrentAudio() {

    if (!currentNoteId) {
        return;
    }


    const confirmed =
        confirm(
            "Delete this recording?"
        );


    if (!confirmed) {
        return;
    }


    await deleteAudio(
        currentNoteId
    );


    savedRecording.innerHTML = "";


    resetRecordingInterface();
}


/* =========================================
   RESET RECORDING UI
========================================= */

function resetRecordingInterface() {

    recordBtn.textContent =
        "🔴  Start Recording";


    recordBtn.classList.remove(
        "recording"
    );


    recordingStatus.classList.remove(
        "active"
    );


    recordingStatus.innerHTML = `

        <div class="microphone">
            🎙️
        </div>

        <p>
            No recording in progress
        </p>

        <small>
            Click "Start Recording" to begin
        </small>

    `;


    savedRecording.innerHTML = "";
}


/* =========================================
   DELETE NOTE
========================================= */

deleteNoteBtn.addEventListener(
    "click",
    async function() {

        if (!currentNoteId) {
            return;
        }


        const confirmed =
            confirm(
                "Delete this note and its recording?"
            );


        if (!confirmed) {
            return;
        }


        await deleteAudio(
            currentNoteId
        );


        notes =
            notes.filter(
                function(note) {

                    return note.id !==
                        currentNoteId;

                }
            );


        saveNotes();


        if (notes.length === 0) {

            createFirstNote();

        } else {

            currentNoteId =
                notes[0].id;

            renderNotes();

            loadCurrentNote();
        }

    }
);


/* =========================================
   SAVE NOTES TO LOCAL STORAGE
========================================= */

function saveNotes() {

    localStorage.setItem(
        "notes",
        JSON.stringify(notes)
    );
}


/* =========================================
   INDEXEDDB
========================================= */

function saveAudio(
    noteId,
    audioBlob
) {

    return new Promise(
        function(resolve, reject) {

            const transaction =
                db.transaction(
                    ["recordings"],
                    "readwrite"
                );


            const store =
                transaction.objectStore(
                    "recordings"
                );


            store.put({

                noteId: noteId,

                audio: audioBlob

            });


            transaction.oncomplete =
                function() {

                    resolve();

                };


            transaction.onerror =
                function() {

                    reject(
                        transaction.error
                    );

                };

        }
    );
}


/* =========================================
   GET AUDIO
========================================= */

function getAudio(noteId) {

    return new Promise(
        function(resolve, reject) {

            const transaction =
                db.transaction(
                    ["recordings"],
                    "readonly"
                );


            const store =
                transaction.objectStore(
                    "recordings"
                );


            const request =
                store.get(noteId);


            request.onsuccess =
                function() {

                    if (request.result) {

                        resolve(
                            request.result.audio
                        );

                    } else {

                        resolve(null);

                    }
                };


            request.onerror =
                function() {

                    reject(
                        request.error
                    );

                };

        }
    );
}


/* =========================================
   DELETE AUDIO
========================================= */

function deleteAudio(noteId) {

    return new Promise(
        function(resolve, reject) {

            const transaction =
                db.transaction(
                    ["recordings"],
                    "readwrite"
                );


            const store =
                transaction.objectStore(
                    "recordings"
                );


            store.delete(noteId);


            transaction.oncomplete =
                function() {

                    resolve();

                };


            transaction.onerror =
                function() {

                    reject(
                        transaction.error
                    );

                };

        }
    );
}


/* =========================================
   FORMAT DATE
========================================= */

function formatDate(dateString) {

    const date =
        new Date(dateString);


    return date.toLocaleString(
        [],
        {
            month: "numeric",
            day: "numeric",
            year: "numeric",
            hour: "numeric",
            minute: "2-digit"
        }
    );
}


/* =========================================
   ESCAPE HTML
========================================= */

function escapeHTML(text) {

    const div =
        document.createElement(
            "div"
        );


    div.textContent = text;


    return div.innerHTML;
}